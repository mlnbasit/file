g++ -no-pie main.cpp curve25519-donna.cpp sha256.cpp sosemanuk.cpp -o d_esxi.out
strip d_esxi.out
