# Babuk Ransomware Source Code
Leaked source code of the babuk ransomware by VXUG
